variable "target_mlops_ami_id" {
  type = string
  sensitive = false
  description = "Required target configuration: mlops ami_id. Supply a validated value."
}
