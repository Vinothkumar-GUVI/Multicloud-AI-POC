# Fill every REQUIRED value before plan/apply. Keep this file private.
# REQUIRED: replace null with your value for target_mlops_ami_id.
target_mlops_ami_id = null
